order BOM
2PCS: VisionFrameV2
2PCS: PCB_Braket
2PCS: LightSealGioV2
4PCS: FANHOLDER
4PCS: FANCATCHER
2PCS: BatPackCase
2PCS: BatPackCaseCover