order BOM
한세트 만드는데 필요한 물품
1개: VisionFrameV2
1개: PCB_Braket
2개: FANHOLDER
2개: FANCATCHER
1개: BatPackCase
1개: BatPackCaseCover